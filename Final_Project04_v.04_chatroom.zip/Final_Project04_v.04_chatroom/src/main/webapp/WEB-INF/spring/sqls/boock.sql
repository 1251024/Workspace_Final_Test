
DROP TABLE CHATROOM;
DROP TABLE MESSAGE;

DROP SEQUENCE message_id;
DROP SEQUENCE CHATROOM_chatroom_id;

CREATE SEQUENCE message_id;
CREATE SEQUENCE CHATROOM_chatroom_id;


CREATE TABLE MESSAGE (
	message_id NUMBER PRIMARY KEY,
	message_sender VARCHAR(45) NOT NULL,
	message_receiver VARCHAR(45) NOT NULL,
	message_content VARCHAR(45) NOT NULL,
	message_sendTime DATE DEFAULT current_timestamp NOT NULL,
	CHATROOM_chatroom_id NUMBER NOT NULL,
	message_readTime DATE DEFAULT current_timestamp NOT NULL,
	User_user_id VARCHAR(45) NOT NULL,
	TUTOR_USER_user_id VARCHAR(45) NOT NULL,
	CLASS_class_id NUMBER NOT NULL
);


CREATE TABLE CHATROOM ( 
	chatroom_id NUMBER PRIMARY KEY,
	User_user_id VARCHAR(45) NOT NULL,
	TUTOR_USER_user_id VARCHAR(45) NOT NULL,
	CLASS_class_id NUMBER NOT NULL 
);
