package com.phoenix.carrot.dao.sns;

public interface WeekendFarmDao {

}
