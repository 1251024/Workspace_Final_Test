package com.phoenix.carrot.biz.sns;

public interface WeekendFarmBiz {

}
