package com.phoenix.carrot.dto.sns;

public class WeekendFarmDto {

}
