package com.phoenix.carrot.dao.sns;

import org.springframework.stereotype.Repository;

@Repository
public class WeekendFarmDaoImpl implements WeekendFarmDao {

}
