package com.phoenix.carrot.biz.sns;

import org.springframework.stereotype.Service;

@Service
public class WeekendFarmBizImpl implements WeekendFarmBiz {

}
